const { useEffect, useMemo, useState } = React;

const CLASSES = ["6th","7th","8th","9th","10th","11th","12th"];

const icon = (name, size=20) => {
  const common = {width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"};
  const paths = {
    home: <><path d="m3 10 9-7 9 7"/><path d="M5 9v11h14V9"/><path d="M9 20v-6h6v6"/></>,
    users: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></>,
    wallet: <><rect x="2" y="5" width="20" height="15" rx="2"/><path d="M16 12h4"/><path d="M2 9h20"/></>,
    calendar: <><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></>,
    file: <><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></>,
    bot: <><rect x="4" y="7" width="16" height="13" rx="3"/><path d="M12 3v4M8 12h.01M16 12h.01M8 16h8"/></>,
    plus: <><path d="M12 5v14M5 12h14"/></>,
    search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></>,
    menu: <><path d="M4 6h16M4 12h16M4 18h16"/></>,
    logout: <><path d="M10 17l5-5-5-5"/><path d="M15 12H3"/><path d="M21 19V5a2 2 0 0 0-2-2h-5"/></>,
    check: <><path d="m5 12 4 4L19 6"/></>,
    x: <><path d="M18 6 6 18M6 6l12 12"/></>,
    whatsapp: <><path d="M20 11.5a8.5 8.5 0 0 1-12.8 7.35L3 20l1.15-4.05A8.5 8.5 0 1 1 20 11.5Z"/><path d="M8 8.5c.2 2.7 2.8 5.3 5.5 5.5.5.04 1-.2 1.3-.65l.4-.6-1.6-.9-.55.55c-1-.35-1.85-1.2-2.2-2.2l.55-.55-.9-1.6-.6.4c-.45.3-.69.8-.65 1.3Z"/></>,
    send: <><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></>,
    chevron: <path d="m9 18 6-6-6-6"/>,
    rupee: <><path d="M6 4h12M6 8h12M10 4c4 0 5 2 5 4 0 3-2 5-6 5l6 7"/></>,
    more: <><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></>
  };
  return React.createElement("svg", common, paths[name] || paths.home);
};

function App() {
  const [token,setToken] = useState(localStorage.getItem("academy_token") || "");
  const [page,setPage] = useState("dashboard");
  const [classFilter,setClassFilter] = useState("all");
  const [dashboard,setDashboard] = useState(null);
  const [students,setStudents] = useState([]);
  const [loading,setLoading] = useState(false);
  const [toast,setToast] = useState("");
  const [installPrompt,setInstallPrompt] = useState(null);
  const [showInstall,setShowInstall] = useState(false);
  const [aiOpen,setAiOpen] = useState(false);

  const notify = (message) => {
    setToast(message);
    setTimeout(()=>setToast(""), 3000);
  };

  useEffect(()=>{
    const handler = e => { e.preventDefault(); setInstallPrompt(e); setShowInstall(true); };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  },[]);

  useEffect(()=>{
    if ("serviceWorker" in navigator) navigator.serviceWorker.register("/service-worker.js").catch(()=>{});
  },[]);

  useEffect(()=>{
    if (token) refreshDashboard();
  },[token,classFilter]);

  async function api(url, options={}) {
    const headers = {"Content-Type":"application/json", ...(options.headers||{})};
    if (token) headers.Authorization = `Bearer ${token}`;
    const response = await fetch(url, {...options, headers});
    const data = await response.json().catch(()=>({}));
    if (!response.ok) {
      if (response.status === 401) {
        localStorage.removeItem("academy_token");
        setToken("");
      }
      throw new Error(data.error || "Request failed");
    }
    return data;
  }

  async function refreshDashboard() {
    try {
      setLoading(true);
      const d = await api(`/api/dashboard${classFilter !== "all" ? `?class=${classFilter}` : ""}`);
      setDashboard(d);
      if (page === "students") loadStudents();
    } catch(e) { notify(e.message); }
    finally { setLoading(false); }
  }

  async function loadStudents() {
    try {
      const d = await api(`/api/students/list${classFilter !== "all" ? `?class=${classFilter}` : ""}`);
      setStudents(d.students || []);
    } catch(e) { notify(e.message); }
  }

  useEffect(()=>{ if(token && page==="students") loadStudents(); },[page,classFilter]);

  async function login(username,password) {
    try {
      const d = await fetch("/api/auth/login", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body:JSON.stringify({username,password})
      });
      const data = await d.json();
      if (!d.ok) throw new Error(data.error || "Login failed");
      localStorage.setItem("academy_token",data.token);
      setToken(data.token);
      notify("Welcome back, Admin");
    } catch(e) { throw e; }
  }

  async function logout() {
    try { await api("/api/auth/logout",{method:"POST"}); } catch {}
    localStorage.removeItem("academy_token");
    setToken("");
  }

  async function installApp() {
    if (!installPrompt) return;
    installPrompt.prompt();
    await installPrompt.userChoice;
    setInstallPrompt(null);
    setShowInstall(false);
  }

  if (!token) return <Login onLogin={login}/>;

  return (
    <div className="min-h-screen bg-[#f7f9fc]">
      {showInstall && (
        <div className="fixed z-[80] inset-x-3 top-3 md:left-auto md:right-5 md:w-[390px]">
          <div className="rounded-2xl bg-slate-950 text-white p-4 shadow-2xl border border-white/10">
            <div className="flex gap-3 items-start">
              <div className="w-11 h-11 rounded-xl bg-blue-600 grid place-items-center shrink-0">{icon("file",22)}</div>
              <div className="flex-1">
                <p className="font-bold">Install Academy App</p>
                <p className="text-xs text-slate-300 mt-1">Install it on your phone for a faster app-like experience.</p>
              </div>
              <button onClick={()=>setShowInstall(false)} className="text-slate-400">{icon("x",18)}</button>
            </div>
            <button onClick={installApp} className="mt-3 w-full rounded-xl bg-white text-slate-950 py-2.5 font-bold text-sm">Install App</button>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto md:flex">
        <Sidebar page={page} setPage={setPage} onLogout={logout}/>
        <main className="flex-1 min-w-0 pb-24 md:pb-8">
          <Topbar page={page} onLogout={logout} setAiOpen={setAiOpen}/>
          <div className="px-4 md:px-7 lg:px-9 py-5">
            <ClassFilters value={classFilter} onChange={setClassFilter}/>
            {page==="dashboard" && <Dashboard dashboard={dashboard} loading={loading} setPage={setPage}/>}
            {page==="students" && <Students students={students} reload={loadStudents} notify={notify}/>}
            {page==="fees" && <Fees api={api} notify={notify}/>}
            {page==="attendance" && <Attendance api={api} notify={notify}/>}
            {page==="tests" && <Tests api={api}/>}
            {page==="ai" && <AIPage api={api} notify={notify}/>}
          </div>
        </main>
      </div>

      <BottomNav page={page} setPage={setPage}/>
      <AIButton onClick={()=>setAiOpen(true)}/>
      {aiOpen && <AIChat api={api} onClose={()=>setAiOpen(false)} notify={notify} setPage={setPage}/>}
      {toast && <div className="fixed z-[100] bottom-24 md:bottom-6 left-1/2 -translate-x-1/2 bg-slate-950 text-white rounded-full px-5 py-3 shadow-xl text-sm font-semibold">{toast}</div>}
    </div>
  );
}

function Login({onLogin}) {
  const [u,setU]=useState("admin"),[p,setP]=useState("admin123"),[busy,setBusy]=useState(false),[error,setError]=useState("");
  async function submit(e){
    e.preventDefault(); setBusy(true); setError("");
    try { await onLogin(u,p); } catch(e){setError(e.message);} finally{setBusy(false);}
  }
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 via-indigo-600 to-violet-700 grid place-items-center p-5">
      <div className="w-full max-w-md">
        <div className="text-center text-white mb-7">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-white/15 backdrop-blur grid place-items-center border border-white/20">{icon("home",32)}</div>
          <h1 className="text-2xl font-black mt-4">Academy Management</h1>
          <p className="text-blue-100 mt-1 text-sm">Admin dashboard · PKR · PWA</p>
        </div>
        <form onSubmit={submit} className="bg-white rounded-3xl p-6 shadow-2xl">
          <h2 className="text-xl font-extrabold">Admin Login</h2>
          <p className="text-sm text-slate-500 mt-1 mb-5">Sign in to manage your academy.</p>
          <label className="text-xs font-bold text-slate-600">Username</label>
          <input value={u} onChange={e=>setU(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500"/>
          <label className="text-xs font-bold text-slate-600 block mt-4">Password</label>
          <input type="password" value={p} onChange={e=>setP(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500"/>
          {error && <div className="mt-4 rounded-xl bg-red-50 text-red-600 text-sm p-3">{error}</div>}
          <button disabled={busy} className="mt-5 w-full rounded-xl bg-blue-600 hover:bg-blue-700 text-white py-3 font-bold disabled:opacity-60">{busy?"Signing in...":"Sign in"}</button>
          <p className="text-center text-xs text-slate-400 mt-4">Default: admin / admin123</p>
        </form>
      </div>
    </div>
  );
}

function Sidebar({page,setPage,onLogout}) {
  const items=[["dashboard","Dashboard","home"],["students","Students","users"],["fees","Fees","wallet"],["attendance","Attendance","calendar"],["tests","Tests","file"],["ai","AI Assistant","bot"]];
  return <aside className="hidden md:flex w-64 shrink-0 min-h-screen bg-white border-r border-slate-200 flex-col sticky top-0 h-screen">
    <div className="p-5 border-b border-slate-100">
      <div className="flex items-center gap-3">
        <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-blue-600 to-violet-600 text-white grid place-items-center">{icon("home",22)}</div>
        <div><p className="font-black leading-none">Academy ERP</p><p className="text-xs text-slate-400 mt-1">Management System</p></div>
      </div>
    </div>
    <nav className="p-3 space-y-1 flex-1">
      {items.map(([id,label,ic])=><button key={id} onClick={()=>setPage(id)} className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-semibold ${page===id?"bg-blue-50 text-blue-700":"text-slate-500 hover:bg-slate-50"}`}>{icon(ic,19)}{label}</button>)}
    </nav>
    <button onClick={onLogout} className="m-3 flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-semibold text-slate-500 hover:bg-red-50 hover:text-red-600">{icon("logout",19)}Logout</button>
  </aside>
}

function Topbar({page,onLogout,setAiOpen}) {
  const labels={dashboard:"Dashboard",students:"Students",fees:"Fees",attendance:"Attendance",tests:"Daily Tests",ai:"AI Assistant"};
  return <header className="sticky top-0 z-40 bg-white/90 backdrop-blur border-b border-slate-200">
    <div className="max-w-7xl mx-auto px-4 md:px-7 lg:px-9 h-16 flex items-center justify-between">
      <div><h1 className="font-black text-lg">{labels[page]}</h1><p className="hidden sm:block text-[11px] text-slate-400">Academy operations at a glance</p></div>
      <div className="flex items-center gap-2">
        <button onClick={()=>setAiOpen(true)} className="w-10 h-10 rounded-xl bg-violet-50 text-violet-600 grid place-items-center">{icon("bot",20)}</button>
        <button className="w-10 h-10 rounded-xl bg-slate-50 text-slate-500 grid place-items-center">{icon("bell",19)}</button>
        <button onClick={onLogout} className="hidden sm:flex w-10 h-10 rounded-xl bg-slate-900 text-white items-center justify-center">{icon("logout",18)}</button>
      </div>
    </div>
  </header>
}

function ClassFilters({value,onChange}) {
  return <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
    <button onClick={()=>onChange("all")} className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap ${value==="all"?"bg-slate-950 text-white":"bg-white border border-slate-200 text-slate-500"}`}>All Classes</button>
    {CLASSES.map(c=><button key={c} onClick={()=>onChange(c)} className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap ${value===c?"bg-blue-600 text-white":"bg-white border border-slate-200 text-slate-500"}`}>{c}</button>)}
  </div>
}

function Dashboard({dashboard,loading,setPage}) {
  const s=dashboard?.stats||{};
  return <div className="space-y-5">
    <section className="rounded-3xl bg-gradient-to-br from-slate-950 via-blue-950 to-blue-700 text-white p-5 md:p-7 shadow-soft overflow-hidden relative">
      <div className="relative z-10 max-w-2xl">
        <p className="text-blue-200 text-xs font-bold uppercase tracking-wider">Good morning, Admin</p>
        <h2 className="text-2xl md:text-3xl font-black mt-2">Run your academy from one dashboard.</h2>
        <p className="text-blue-100/80 text-sm mt-2">Students, fees, attendance and daily tests — all in one place.</p>
        <div className="flex flex-wrap gap-2 mt-5">
          <button onClick={()=>setPage("students")} className="bg-white text-slate-950 rounded-xl px-4 py-2.5 text-sm font-bold">Manage Students</button>
          <button onClick={()=>setPage("attendance")} className="bg-white/10 border border-white/20 rounded-xl px-4 py-2.5 text-sm font-bold">Mark Attendance</button>
        </div>
      </div>
      <div className="absolute -right-10 -bottom-20 w-64 h-64 rounded-full bg-blue-400/20 blur-2xl"></div>
      <div className="absolute right-8 top-8 opacity-10">{icon("home",110)}</div>
    </section>
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      <StatCard title="Students" value={s.students??"—"} iconName="users" tone="blue"/>
      <StatCard title="Collected Today" value={`Rs. ${Number(s.collectedToday||0).toLocaleString("en-PK")}`} iconName="wallet" tone="emerald"/>
      <StatCard title="Pending Fees" value={`Rs. ${Number(s.pendingFees||0).toLocaleString("en-PK")}`} iconName="rupee" tone="amber"/>
      <StatCard title="Absent Today" value={s.absentToday??"—"} iconName="calendar" tone="rose"/>
    </div>
    <div className="grid lg:grid-cols-3 gap-4">
      <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-200 p-5 shadow-soft">
        <div className="flex justify-between items-center mb-4"><div><h3 className="font-black">Recent Activity</h3><p className="text-xs text-slate-400 mt-1">Latest academy updates</p></div><button onClick={()=>setPage("ai")} className="text-xs font-bold text-blue-600">Ask AI</button></div>
        <div className="space-y-3">
          {(dashboard?.activity||[]).length ? dashboard.activity.map(a=><Activity key={a.id} item={a}/>) : <Empty text="No recent activity yet."/>}
        </div>
      </div>
      <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-soft">
        <h3 className="font-black">Today's Snapshot</h3>
        <div className="mt-4 space-y-4">
          <Progress label="Present" value={s.presentToday||0} max={Math.max(1,s.presentToday+s.absentToday)} />
          <Progress label="Absent" value={s.absentToday||0} max={Math.max(1,s.presentToday+s.absentToday)} />
          <div className="rounded-2xl bg-violet-50 p-4">
            <p className="text-xs font-bold text-violet-600">Daily Test</p>
            <p className="font-black mt-1">11:00 AM</p>
            <p className="text-xs text-violet-500 mt-1">ETEA-style test schedule</p>
          </div>
        </div>
      </div>
    </div>
  </div>
}

function StatCard({title,value,iconName,tone}) {
  const tones={blue:"bg-blue-50 text-blue-600",emerald:"bg-emerald-50 text-emerald-600",amber:"bg-amber-50 text-amber-600",rose:"bg-rose-50 text-rose-600"};
  return <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-soft"><div className={`w-10 h-10 rounded-xl grid place-items-center ${tones[tone]}`}>{icon(iconName,19)}</div><p className="text-xs text-slate-400 mt-3 font-semibold">{title}</p><p className="font-black text-lg mt-1 truncate">{value}</p></div>
}

function Activity({item}) {
  const colors={fee:"bg-emerald-50 text-emerald-600",attendance:"bg-blue-50 text-blue-600",student:"bg-violet-50 text-violet-600",ai:"bg-amber-50 text-amber-600"};
  const ico=item.type==="fee"?"wallet":item.type==="attendance"?"calendar":item.type==="student"?"users":"bot";
  return <div className="flex gap-3 items-center"><div className={`w-9 h-9 rounded-xl grid place-items-center shrink-0 ${colors[item.type]||colors.ai}`}>{icon(ico,17)}</div><div className="min-w-0 flex-1"><p className="text-sm font-semibold truncate">{item.message}</p><p className="text-[11px] text-slate-400">{new Date(item.time).toLocaleString()}</p></div></div>
}
function Progress({label,value,max}) {const pct=Math.min(100,Math.round(value/max*100));return <div><div className="flex justify-between text-xs font-bold"><span>{label}</span><span>{value}</span></div><div className="h-2 bg-slate-100 rounded-full mt-2 overflow-hidden"><div className="h-full bg-blue-600 rounded-full" style={{width:`${pct}%`}}></div></div></div>}
function Empty({text}) {return <div className="py-10 text-center text-sm text-slate-400">{text}</div>}

function Students({students,reload,notify}) {
  const [open,setOpen]=useState(false),[editing,setEditing]=useState(null),[search,setSearch]=useState("");
  const filtered=students.filter(s=>[s.name,s.fatherName,s.phone,s.rollNo,s.class].join(" ").toLowerCase().includes(search.toLowerCase()));
  return <div className="space-y-4">
    <div className="flex flex-col sm:flex-row gap-3 justify-between">
      <div className="relative flex-1 max-w-lg"><span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">{icon("search",18)}</span><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search students..." className="w-full bg-white border border-slate-200 rounded-xl py-3 pl-10 pr-4 outline-none focus:ring-2 focus:ring-blue-500"/></div>
      <button onClick={()=>{setEditing(null);setOpen(true)}} className="bg-blue-600 text-white rounded-xl px-4 py-3 font-bold text-sm flex items-center justify-center gap-2">{icon("plus",17)}Add Student</button>
    </div>
    <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-soft">
      <div className="p-4 border-b border-slate-100 flex justify-between"><div><h3 className="font-black">Student Directory</h3><p className="text-xs text-slate-400 mt-1">{filtered.length} records</p></div></div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[720px] text-sm"><thead className="bg-slate-50 text-xs text-slate-500"><tr><th className="text-left p-4">Student</th><th className="text-left p-4">Class</th><th className="text-left p-4">Roll No</th><th className="text-left p-4">Phone</th><th className="text-left p-4">Fee</th><th className="text-right p-4">Action</th></tr></thead>
        <tbody>{filtered.map(s=><tr key={s.id} className="border-t border-slate-100"><td className="p-4"><div className="font-bold">{s.name}</div><div className="text-xs text-slate-400">{s.fatherName||"Father name not set"}</div></td><td className="p-4"><span className="rounded-full bg-blue-50 text-blue-700 px-2.5 py-1 text-xs font-bold">{s.class}</span></td><td className="p-4">{s.rollNo||"—"}</td><td className="p-4">{s.phone||"—"}</td><td className="p-4"><span className={s.feeStatus==="paid"?"text-emerald-600":"text-amber-600"}>{s.feeStatus==="paid"?"Paid":"Pending"} · Rs. {Number(s.fee||0).toLocaleString("en-PK")}</span></td><td className="p-4 text-right"><button onClick={()=>{setEditing(s);setOpen(true)}} className="text-blue-600 font-bold text-xs mr-3">Edit</button></td></tr>)}</tbody></table>
      </div>
      {!filtered.length&&<Empty text="No students found."/>}
    </div>
    {open&&<StudentModal student={editing} onClose={()=>setOpen(false)} onSaved={()=>{setOpen(false);reload();notify("Student saved")}}/>}
  </div>
}

function StudentModal({student,onClose,onSaved}) {
  const [form,setForm]=useState(student||{name:"",fatherName:"",class:"9th",phone:"",rollNo:"",fee:3000});
  const [busy,setBusy]=useState(false);
  const save=async e=>{
    e.preventDefault();setBusy(true);
    try{
      const token=localStorage.getItem("academy_token");
      const url=student?`/api/students/${student.id}`:"/api/students/add";
      const r=await fetch(url,{method:student?"PUT":"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${token}`},body:JSON.stringify(form)});
      const d=await r.json();if(!r.ok)throw new Error(d.error||"Save failed");onSaved();
    }catch(e){alert(e.message)}finally{setBusy(false)}
  };
  return <Modal title={student?"Edit Student":"Add Student"} onClose={onClose}><form onSubmit={save} className="grid sm:grid-cols-2 gap-4">
    <Field label="Student name" value={form.name} onChange={v=>setForm({...form,name:v})} required/>
    <Field label="Father name" value={form.fatherName} onChange={v=>setForm({...form,fatherName:v})}/>
    <label className="text-sm font-semibold">Class<select value={form.class} onChange={e=>setForm({...form,class:e.target.value})} className="mt-1 w-full border rounded-xl px-3 py-3">{CLASSES.map(c=><option key={c}>{c}</option>)}</select></label>
    <Field label="Phone" value={form.phone} onChange={v=>setForm({...form,phone:v})} placeholder="03XX-XXXXXXX"/>
    <Field label="Roll No" value={form.rollNo} onChange={v=>setForm({...form,rollNo:v})}/>
    <Field label="Monthly fee (Rs.)" type="number" value={form.fee} onChange={v=>setForm({...form,fee:v})}/>
    <div className="sm:col-span-2 flex gap-2 justify-end pt-2"><button type="button" onClick={onClose} className="px-4 py-3 rounded-xl bg-slate-100 font-bold">Cancel</button><button disabled={busy} className="px-5 py-3 rounded-xl bg-blue-600 text-white font-bold">{busy?"Saving...":"Save Student"}</button></div>
  </form></Modal>
}

function Field({label,value,onChange,type="text",placeholder="",required=false}) {return <label className="text-sm font-semibold">{label}<input required={required} type={type} value={value} placeholder={placeholder} onChange={e=>onChange(e.target.value)} className="mt-1 w-full border border-slate-200 rounded-xl px-3 py-3 outline-none focus:ring-2 focus:ring-blue-500"/></label>}
function Modal({title,onClose,children}) {return <div className="fixed inset-0 z-[90] bg-slate-950/50 backdrop-blur-sm grid place-items-end sm:place-items-center p-0 sm:p-5"><div className="w-full sm:max-w-xl bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl max-h-[90vh] overflow-y-auto"><div className="p-5 border-b flex justify-between items-center"><h3 className="font-black">{title}</h3><button onClick={onClose}>{icon("x",20)}</button></div><div className="p-5">{children}</div></div></div>}

function Fees({api,notify}) {
  const [students,setStudents]=useState([]),[selected,setSelected]=useState(""),[amount,setAmount]=useState(""),[pending,setPending]=useState(null);
  async function load(){const s=await api("/api/students/list");setStudents(s.students||[]);setPending(await api("/api/fees/pending"))}
  useEffect(()=>{load().catch(e=>notify(e.message))},[]);
  async function collect(e){e.preventDefault();try{await api("/api/fees/collect",{method:"POST",body:JSON.stringify({studentId:selected,amount:Number(amount)})});notify("Fee collected");setAmount("");setSelected("");load()}catch(e){notify(e.message)}}
  return <div className="grid lg:grid-cols-3 gap-4">
    <form onSubmit={collect} className="bg-white border rounded-3xl p-5 shadow-soft">
      <h3 className="font-black text-lg">Collect Fee</h3><p className="text-xs text-slate-400 mt-1">Currency: Rs. PKR</p>
      <label className="text-sm font-semibold block mt-5">Student<select required value={selected} onChange={e=>setSelected(e.target.value)} className="mt-1 w-full border rounded-xl px-3 py-3"><option value="">Select student</option>{students.map(s=><option key={s.id} value={s.id}>{s.name} · {s.class}</option>)}</select></label>
      <Field label="Amount (Rs.)" type="number" value={amount} onChange={setAmount} />
      <button className="w-full mt-5 bg-emerald-600 text-white rounded-xl py-3 font-bold">Collect Rs. {Number(amount||0).toLocaleString("en-PK")}</button>
    </form>
    <div className="lg:col-span-2 bg-white border rounded-3xl p-5 shadow-soft">
      <div className="flex justify-between"><div><h3 className="font-black">Pending Fees</h3><p className="text-xs text-slate-400 mt-1">{pending?.count||0} students · Rs. {Number(pending?.total||0).toLocaleString("en-PK")}</p></div><span className="text-amber-600 bg-amber-50 px-3 py-2 rounded-xl text-xs font-bold">PKR</span></div>
      <div className="mt-4 space-y-2">{(pending?.students||[]).map(s=><div key={s.id} className="p-3 rounded-2xl bg-slate-50 flex items-center justify-between"><div><p className="font-bold text-sm">{s.name}</p><p className="text-xs text-slate-400">{s.class} · {s.phone||"No phone"}</p></div><p className="font-black text-amber-600">Rs. {Number(s.fee||0).toLocaleString("en-PK")}</p></div>)}{!pending?.students?.length&&<Empty text="No pending fees."/>}</div>
    </div>
  </div>
}

function Attendance({api,notify}) {
  const [cls,setCls]=useState("9th"),[students,setStudents]=useState([]),[absent,setAbsent]=useState(new Set()),[saved,setSaved]=useState(false),[wa,setWa]=useState([]);
  async function load(){const s=await api(`/api/students/list?class=${cls}`);setStudents(s.students||[]);const a=await api(`/api/attendance/absent?class=${cls}`);setAbsent(new Set((a.students||[]).map(x=>x.id)));setWa(a.whatsappLinks||[]);setSaved(false)}
  useEffect(()=>{load().catch(e=>notify(e.message))},[cls]);
  function toggle(id){const n=new Set(absent);n.has(id)?n.delete(id):n.add(id);setAbsent(n)}
  async function save(){try{const present=students.filter(s=>!absent.has(s.id)).map(s=>s.id);await api("/api/attendance/mark",{method:"POST",body:JSON.stringify({class:cls,presentIds:present,absentIds:[...absent]})});notify("Attendance saved");load()}catch(e){notify(e.message)}}
  async function refreshWa(){const a=await api(`/api/attendance/absent?class=${cls}`);setWa(a.whatsappLinks||[])}
  return <div className="space-y-4">
    <div className="bg-white border rounded-3xl p-5 shadow-soft flex flex-col sm:flex-row gap-3 justify-between sm:items-center"><div><h3 className="font-black">Mark Attendance</h3><p className="text-xs text-slate-400 mt-1">Tap a student to toggle absent/present.</p></div><select value={cls} onChange={e=>setCls(e.target.value)} className="border rounded-xl px-3 py-2.5 font-bold">{CLASSES.map(c=><option key={c}>{c}</option>)}</select></div>
    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">{students.map(s=><button key={s.id} onClick={()=>toggle(s.id)} className={`text-left p-4 rounded-2xl border ${absent.has(s.id)?"bg-rose-50 border-rose-200":"bg-white border-slate-200"}`}><div className="flex items-center justify-between"><div><p className="font-bold">{s.name}</p><p className="text-xs text-slate-400 mt-1">Roll {s.rollNo||"—"}</p></div><span className={`w-9 h-9 rounded-full grid place-items-center ${absent.has(s.id)?"bg-rose-100 text-rose-600":"bg-emerald-100 text-emerald-600"}`}>{icon(absent.has(s.id)?"x":"check",17)}</span></div><p className={`text-xs font-bold mt-3 ${absent.has(s.id)?"text-rose-600":"text-emerald-600"}`}>{absent.has(s.id)?"ABSENT":"PRESENT"}</p></button>)}</div>
    <div className="flex flex-wrap gap-2"><button onClick={save} className="bg-blue-600 text-white rounded-xl px-5 py-3 font-bold">Save Attendance</button><button onClick={refreshWa} className="bg-emerald-600 text-white rounded-xl px-5 py-3 font-bold flex gap-2 items-center">{icon("whatsapp",17)}Prepare WhatsApp</button></div>
    {wa.length>0&&<div className="bg-white border rounded-3xl p-5"><h3 className="font-black">Absent WhatsApp Links</h3><div className="mt-3 flex flex-wrap gap-2">{wa.map(x=><a key={x.id} target="_blank" href={x.url} className="bg-emerald-50 text-emerald-700 rounded-xl px-3 py-2 text-sm font-bold">{x.name}</a>)}</div></div>}
  </div>
}

function Tests({api}) {
  const [test,setTest]=useState(null);
  useEffect(()=>{api("/api/tests/today").then(setTest).catch(()=>{})},[]);
  return <div className="space-y-4">
    <div className="rounded-3xl bg-gradient-to-br from-violet-700 to-blue-600 text-white p-6 shadow-soft"><p className="text-violet-100 text-xs font-bold uppercase tracking-wider">Daily testing</p><h2 className="text-2xl font-black mt-2">ETEA Style Test</h2><p className="text-violet-100 mt-1">Every day at 11:00 AM · 40 minutes</p><div className="mt-5 inline-flex rounded-xl bg-white/15 border border-white/20 px-4 py-2 text-sm font-bold">{test?.status?.toUpperCase()||"LOADING"}</div></div>
    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
      <InfoCard title="Time" value="11:00 AM"/>
      <InfoCard title="Duration" value="40 min"/>
      <InfoCard title="Classes" value="6th–12th"/>
      <InfoCard title="Mode" value="Online"/>
    </div>
  </div>
}
function InfoCard({title,value}){return <div className="bg-white border rounded-2xl p-4"><p className="text-xs text-slate-400">{title}</p><p className="font-black mt-2">{value}</p></div>}

function AIPage({api,notify}) {
  const [cmd,setCmd]=useState(""),[result,setResult]=useState(null),[busy,setBusy]=useState(false);
  async function run(e){e.preventDefault();if(!cmd.trim())return;setBusy(true);try{setResult(await api("/api/ai/command",{method:"POST",body:JSON.stringify({command:cmd})}));setCmd("")}catch(e){notify(e.message)}finally{setBusy(false)}}
  return <div className="max-w-3xl">
    <div className="rounded-3xl bg-slate-950 text-white p-6 shadow-soft"><div className="w-12 h-12 rounded-2xl bg-violet-600 grid place-items-center">{icon("bot",24)}</div><h2 className="text-2xl font-black mt-4">Academy AI Assistant</h2><p className="text-slate-400 mt-1">Roman Urdu commands bhi samajhta hai.</p>
      <form onSubmit={run} className="mt-5 flex gap-2"><input value={cmd} onChange={e=>setCmd(e.target.value)} placeholder='e.g. "Ahmad ko hazir karo"' className="flex-1 rounded-xl bg-white/10 border border-white/10 px-4 py-3 outline-none focus:ring-2 focus:ring-violet-500"/><button disabled={busy} className="w-12 rounded-xl bg-violet-600 grid place-items-center">{icon("send",18)}</button></form>
      <div className="flex flex-wrap gap-2 mt-4">{["Ahmad ko hazir karo","9th ki pending fee","Absent ko WhatsApp bhejo","Add student Bilal class 10th phone 0345-1234567"].map(x=><button key={x} onClick={()=>setCmd(x)} className="text-xs rounded-full bg-white/10 px-3 py-2 text-slate-300">{x}</button>)}</div>
    </div>
    {result&&<div className="mt-4 bg-white border rounded-3xl p-5"><p className="font-bold">{result.message}</p>{result.data?.students&&<div className="mt-4 space-y-2">{result.data.students.map(s=><div key={s.id} className="p-3 bg-slate-50 rounded-xl flex justify-between"><span className="font-semibold">{s.name}</span><span className="text-xs text-slate-500">{s.class}</span></div>)}</div>}{result.data?.links&&<div className="mt-4 flex flex-wrap gap-2">{result.data.links.map((x,i)=><a key={i} href={x.url} target="_blank" className="bg-emerald-50 text-emerald-700 rounded-xl px-3 py-2 text-xs font-bold">{x.name} WhatsApp</a>)}</div>}</div>}
  </div>
}

function AIButton({onClick}){return <button onClick={onClick} className="fixed right-4 bottom-20 md:bottom-6 z-50 w-14 h-14 rounded-full bg-gradient-to-br from-violet-600 to-blue-600 text-white shadow-2xl grid place-items-center border-4 border-white">{icon("bot",24)}</button>}

function AIChat({api,onClose,notify,setPage}) {
  const [messages,setMessages]=useState([{role:"ai",text:"Assalam o Alaikum! Main academy AI assistant hoon. Aap Roman Urdu mein command de sakte hain."}]);
  const [input,setInput]=useState(""),[busy,setBusy]=useState(false);
  async function send(e){e?.preventDefault();const c=input.trim();if(!c)return;setMessages(m=>[...m,{role:"user",text:c}]);setInput("");setBusy(true);try{const r=await api("/api/ai/command",{method:"POST",body:JSON.stringify({command:c})});setMessages(m=>[...m,{role:"ai",text:r.message||"Done."}]);if(r.type==="students")setPage("students");else if(r.type==="fee_pending")setPage("fees");else if(r.type==="attendance")setPage("attendance")}catch(e){notify(e.message)}finally{setBusy(false)}}
  return <div className="fixed z-[85] right-3 bottom-20 md:right-5 md:bottom-24 w-[calc(100%-24px)] max-w-sm"><div className="bg-white border border-slate-200 rounded-3xl shadow-2xl overflow-hidden"><div className="bg-slate-950 text-white p-4 flex items-center justify-between"><div className="flex items-center gap-2"><div className="w-9 h-9 rounded-xl bg-violet-600 grid place-items-center">{icon("bot",18)}</div><div><p className="font-black text-sm">Academy AI</p><p className="text-[10px] text-slate-400">Roman Urdu enabled</p></div></div><button onClick={onClose}>{icon("x",19)}</button></div><div className="h-72 overflow-y-auto p-4 space-y-3 bg-slate-50">{messages.map((m,i)=><div key={i} className={`flex ${m.role==="user"?"justify-end":""}`}><div className={`max-w-[85%] rounded-2xl px-3 py-2 text-sm ${m.role==="user"?"bg-blue-600 text-white rounded-br-md":"bg-white border text-slate-700 rounded-bl-md"}`}>{m.text}</div></div>)}{busy&&<div className="text-xs text-slate-400">AI is working...</div>}</div><form onSubmit={send} className="p-3 border-t flex gap-2"><input value={input} onChange={e=>setInput(e.target.value)} placeholder="Command likhein..." className="flex-1 bg-slate-100 rounded-xl px-3 py-2.5 text-sm outline-none"/><button className="w-10 rounded-xl bg-violet-600 text-white grid place-items-center">{icon("send",16)}</button></form></div></div>
}

function BottomNav({page,setPage}) {
  const items=[["dashboard","Home","home"],["students","Students","users"],["fees","Fees","wallet"],["attendance","Attendance","calendar"],["ai","AI","bot"]];
  return <nav className="md:hidden fixed z-50 bottom-0 inset-x-0 bg-white/95 backdrop-blur border-t border-slate-200 safe-bottom"><div className="grid grid-cols-5">{items.map(([id,l,ic])=><button key={id} onClick={()=>setPage(id)} className={`py-3 flex flex-col items-center gap-1 text-[10px] font-bold ${page===id?"text-blue-600":"text-slate-400"}`}>{icon(ic,19)}{l}</button>)}</div></nav>
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
