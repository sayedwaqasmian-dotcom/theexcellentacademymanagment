# Academy Management System

A mobile-first full-stack academy management system built with:

- Node.js + Express
- React (browser runtime)
- Tailwind CSS
- JSON file database at `data/db.json`
- PWA manifest + service worker
- PKR currency
- Roman Urdu AI command parser
- Admin authentication

## Default login

- Username: `admin`
- Password: `admin123`

Change these with environment variables before selling/deploying.

## Run locally

```bash
npm install
npm start
```

Open:

```text
http://localhost:3000
```

## Project structure

```text
academy-management-system/
├── data/
│   └── db.json
├── public/
│   ├── index.html
│   ├── app.js
│   ├── manifest.json
│   ├── service-worker.js
│   └── icon.svg
├── .env.example
├── .gitignore
├── package.json
├── README.md
└── server.js
```

## Render deployment (recommended for JSON database)

1. Create a new Web Service on Render.
2. Connect this repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variables from `.env.example`.
6. For real persistent JSON data, attach a persistent disk and mount it so `/data` lives on that disk.

### Important

The local JSON database is suitable for a simple single-instance deployment. Serverless platforms such as Vercel/Netlify do not guarantee persistent writes to a local filesystem. If you need Vercel/Netlify with permanent data, replace the JSON storage layer with a hosted database such as Postgres/Supabase/Firebase.

## Included API

### Auth
- `POST /api/auth/login`

### Students
- `POST /api/students/add`
- `GET /api/students/list`
- `PUT /api/students/:id`
- `DELETE /api/students/:id`

### Fees
- `POST /api/fees/collect`
- `GET /api/fees/pending`
- `GET /api/fees/summary`

### Attendance
- `POST /api/attendance/mark`
- `GET /api/attendance/absent`
- `GET /api/attendance/today`

### Dashboard
- `GET /api/dashboard`

### Tests
- `GET /api/tests/today`

### AI
- `POST /api/ai/command`

## Supported AI commands

Examples:

- `Add student Bilal class 10th phone 0345-1234567`
- `Bilal ko class 10th mein add karo phone 0345-1234567`
- `Ahmad ko hazir karo`
- `Ahmad ko absent karo`
- `9th ki pending fee`
- `10th ke students dikhao`
- `Absent ko WhatsApp bhejo`
- `dashboard dikhao`
- `aaj ki attendance`
- `11am test status`

## Productization

For a Rs. 5000/academy product, create a separate deployment/database per academy or add a tenant ID and proper hosted database before scaling to many academies. The included app is intentionally simple and easy to customize.
