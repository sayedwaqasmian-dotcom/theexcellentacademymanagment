require("dotenv").config();

const express = require("express");
const cors = require("cors");
const path = require("path");
const fs = require("fs/promises");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, "public");
const DATA_DIR = path.join(ROOT, "data");
const DB_FILE = path.join(DATA_DIR, "db.json");

const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin123";
const SESSION_SECRET = process.env.SESSION_SECRET || "academy-dev-secret";

app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));

const classes = ["6th", "7th", "8th", "9th", "10th", "11th", "12th"];
const sessions = new Map();

function uid(prefix) {
  return `${prefix}_${crypto.randomBytes(8).toString("hex")}`;
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

function normalizeClass(value) {
  if (!value) return "";
  const raw = String(value).toLowerCase().trim();
  const match = raw.match(/(6|7|8|9|10|11|12)(?:th|st|nd|rd)?/);
  return match ? `${match[1]}th` : raw;
}

function normalizePhone(value) {
  return String(value || "").replace(/[^\d+]/g, "").replace(/^(\+92|0092)/, "0");
}

async function ensureDb() {
  await fs.mkdir(DATA_DIR, { recursive: true });
  try {
    await fs.access(DB_FILE);
  } catch {
    await fs.writeFile(DB_FILE, JSON.stringify({
      students: [], fees: [], attendance: [], activity: [], tests: []
    }, null, 2));
  }
}

let writeQueue = Promise.resolve();

async function readDb() {
  await ensureDb();
  const raw = await fs.readFile(DB_FILE, "utf8");
  return JSON.parse(raw);
}

function writeDb(db) {
  writeQueue = writeQueue.then(async () => {
    const tmp = `${DB_FILE}.tmp`;
    await fs.writeFile(tmp, JSON.stringify(db, null, 2));
    await fs.rename(tmp, DB_FILE);
  });
  return writeQueue;
}

async function addActivity(db, type, message) {
  db.activity = db.activity || [];
  db.activity.unshift({
    id: uid("act"),
    type,
    message,
    time: new Date().toISOString()
  });
  db.activity = db.activity.slice(0, 50);
}

function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  const session = sessions.get(token);
  if (!session) return res.status(401).json({ error: "Unauthorized" });
  next();
}

app.get("/api/health", (req, res) => {
  res.json({ ok: true, app: "Academy Management System", time: new Date().toISOString() });
});

app.post("/api/auth/login", (req, res) => {
  const { username, password } = req.body || {};
  if (username !== ADMIN_USERNAME || password !== ADMIN_PASSWORD) {
    return res.status(401).json({ error: "Invalid username or password" });
  }

  const token = crypto.createHmac("sha256", SESSION_SECRET)
    .update(`${username}:${Date.now()}:${crypto.randomBytes(16).toString("hex")}`)
    .digest("hex");

  sessions.set(token, { username, createdAt: Date.now() });
  res.json({ token, user: { username, role: "admin" } });
});

app.post("/api/auth/logout", auth, (req, res) => {
  const token = (req.headers.authorization || "").slice(7);
  sessions.delete(token);
  res.json({ ok: true });
});

app.get("/api/dashboard", auth, async (req, res) => {
  const db = await readDb();
  const activeClass = normalizeClass(req.query.class);
  const students = activeClass ? db.students.filter(s => s.class === activeClass) : db.students;

  const pendingFees = students.filter(s => s.feeStatus !== "paid")
    .reduce((sum, s) => sum + Number(s.fee || 0), 0);

  const paidFees = (db.fees || []).filter(f => f.date === today() && f.status === "paid")
    .reduce((sum, f) => sum + Number(f.amount || 0), 0);

  const att = (db.attendance || []).filter(a => a.date === today());
  const presentIds = new Set(att.flatMap(a => a.presentIds || []));
  const absentIds = new Set(att.flatMap(a => a.absentIds || []));

  res.json({
    stats: {
      students: students.length,
      pendingFees,
      collectedToday: paidFees,
      presentToday: presentIds.size,
      absentToday: absentIds.size
    },
    activity: (db.activity || []).slice(0, 8),
    class: activeClass || "all"
  });
});

app.post("/api/students/add", auth, async (req, res) => {
  const { name, fatherName = "", class: classValue, phone = "", rollNo = "", fee = 0 } = req.body || {};
  const studentClass = normalizeClass(classValue);

  if (!name || !studentClass || !classes.includes(studentClass)) {
    return res.status(400).json({ error: "name and valid class (6th-12th) are required" });
  }

  const db = await readDb();
  const student = {
    id: uid("stu"),
    name: String(name).trim(),
    fatherName: String(fatherName).trim(),
    class: studentClass,
    phone: normalizePhone(phone),
    rollNo: String(rollNo).trim(),
    fee: Number(fee || 0),
    feeStatus: "pending",
    attendance: "unmarked",
    createdAt: new Date().toISOString()
  };

  db.students.unshift(student);
  await addActivity(db, "student", `${student.name} added to ${student.class} class`);
  await writeDb(db);

  res.status(201).json({ message: "Student added", student });
});

app.get("/api/students/list", auth, async (req, res) => {
  const db = await readDb();
  const classValue = normalizeClass(req.query.class);
  const q = String(req.query.q || "").toLowerCase().trim();

  let students = db.students || [];
  if (classValue) students = students.filter(s => s.class === classValue);
  if (q) {
    students = students.filter(s =>
      [s.name, s.fatherName, s.phone, s.rollNo, s.class].join(" ").toLowerCase().includes(q)
    );
  }

  res.json({ students });
});

app.put("/api/students/:id", auth, async (req, res) => {
  const db = await readDb();
  const index = db.students.findIndex(s => s.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: "Student not found" });

  const current = db.students[index];
  const body = req.body || {};

  const updated = {
    ...current,
    name: body.name !== undefined ? String(body.name).trim() : current.name,
    fatherName: body.fatherName !== undefined ? String(body.fatherName).trim() : current.fatherName,
    class: body.class !== undefined ? normalizeClass(body.class) : current.class,
    phone: body.phone !== undefined ? normalizePhone(body.phone) : current.phone,
    rollNo: body.rollNo !== undefined ? String(body.rollNo).trim() : current.rollNo,
    fee: body.fee !== undefined ? Number(body.fee || 0) : current.fee,
    feeStatus: body.feeStatus !== undefined ? body.feeStatus : current.feeStatus,
    attendance: body.attendance !== undefined ? body.attendance : current.attendance
  };

  db.students[index] = updated;
  await addActivity(db, "student", `${updated.name} updated`);
  await writeDb(db);
  res.json({ message: "Student updated", student: updated });
});

app.delete("/api/students/:id", auth, async (req, res) => {
  const db = await readDb();
  const index = db.students.findIndex(s => s.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: "Student not found" });

  const [removed] = db.students.splice(index, 1);
  await addActivity(db, "student", `${removed.name} deleted`);
  await writeDb(db);
  res.json({ message: "Student deleted" });
});

app.post("/api/fees/collect", auth, async (req, res) => {
  const { studentId, amount } = req.body || {};
  const numericAmount = Number(amount);

  if (!studentId || !numericAmount || numericAmount <= 0) {
    return res.status(400).json({ error: "studentId and positive amount are required" });
  }

  const db = await readDb();
  const student = db.students.find(s => s.id === studentId);
  if (!student) return res.status(404).json({ error: "Student not found" });

  const fee = {
    id: uid("fee"),
    studentId,
    amount: numericAmount,
    date: today(),
    status: "paid"
  };

  db.fees.unshift(fee);
  student.feeStatus = "paid";
  await addActivity(db, "fee", `Fee collected from ${student.name}: Rs. ${numericAmount.toLocaleString("en-PK")}`);
  await writeDb(db);

  res.status(201).json({ message: "Fee collected", fee, student });
});

app.get("/api/fees/pending", auth, async (req, res) => {
  const db = await readDb();
  const classValue = normalizeClass(req.query.class);
  let students = (db.students || []).filter(s => s.feeStatus !== "paid");
  if (classValue) students = students.filter(s => s.class === classValue);

  res.json({
    class: classValue || "all",
    total: students.reduce((sum, s) => sum + Number(s.fee || 0), 0),
    count: students.length,
    students
  });
});

app.get("/api/fees/summary", auth, async (req, res) => {
  const db = await readDb();
  const paid = (db.fees || []).filter(f => f.status === "paid");
  const totalCollected = paid.reduce((sum, f) => sum + Number(f.amount || 0), 0);
  const pending = (db.students || []).filter(s => s.feeStatus !== "paid")
    .reduce((sum, s) => sum + Number(s.fee || 0), 0);
  res.json({ totalCollected, pending });
});

app.post("/api/attendance/mark", auth, async (req, res) => {
  const { date = today(), class: classValue, presentIds = [], absentIds = [] } = req.body || {};
  const studentClass = normalizeClass(classValue);

  if (!classes.includes(studentClass)) {
    return res.status(400).json({ error: "Valid class is required" });
  }

  const db = await readDb();
  const normalizedPresent = Array.isArray(presentIds) ? presentIds : [];
  const normalizedAbsent = Array.isArray(absentIds) ? absentIds : [];

  let record = db.attendance.find(a => a.date === date && a.class === studentClass);
  if (!record) {
    record = { id: uid("att"), date, class: studentClass, presentIds: [], absentIds: [] };
    db.attendance.push(record);
  }

  record.presentIds = normalizedPresent;
  record.absentIds = normalizedAbsent;

  for (const s of db.students) {
    if (s.class !== studentClass) continue;
    if (normalizedPresent.includes(s.id)) s.attendance = "present";
    else if (normalizedAbsent.includes(s.id)) s.attendance = "absent";
  }

  await addActivity(db, "attendance", `${studentClass} attendance marked: ${normalizedPresent.length} present, ${normalizedAbsent.length} absent`);
  await writeDb(db);

  res.json({ message: "Attendance saved", record });
});

app.get("/api/attendance/absent", auth, async (req, res) => {
  const date = req.query.date || today();
  const classValue = normalizeClass(req.query.class);
  const db = await readDb();

  const absentIds = new Set(
    (db.attendance || [])
      .filter(a => a.date === date && (!classValue || a.class === classValue))
      .flatMap(a => a.absentIds || [])
  );

  const students = (db.students || []).filter(s => absentIds.has(s.id));
  const links = students
    .filter(s => s.phone)
    .map(s => ({
      id: s.id,
      name: s.name,
      phone: s.phone,
      url: `https://wa.me/${normalizePhone(s.phone).replace(/^0/, "92")}?text=${encodeURIComponent(`Assalam o Alaikum ${s.name}, aap aaj academy mein absent thay. Barah-e-karam academy se rabta karein.`)}`
    }));

  res.json({ date, class: classValue || "all", students, whatsappLinks: links });
});

app.get("/api/attendance/today", auth, async (req, res) => {
  const db = await readDb();
  const date = today();
  const records = (db.attendance || []).filter(a => a.date === date);
  res.json({ date, records });
});

app.get("/api/tests/today", auth, async (req, res) => {
  const db = await readDb();
  const date = today();
  let test = (db.tests || []).find(t => t.date === date);

  if (!test) {
    test = {
      id: uid("test"),
      title: "Daily ETEA Style Test",
      date,
      time: "11:00",
      status: "scheduled",
      classes
    };
    db.tests.unshift(test);
    await writeDb(db);
  }

  const now = new Date();
  const [h, m] = test.time.split(":").map(Number);
  const testStart = new Date(`${date}T${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:00`);
  const end = new Date(testStart.getTime() + 40 * 60 * 1000);

  let status = "scheduled";
  if (now >= testStart && now <= end) status = "live";
  if (now > end) status = "completed";

  res.json({ ...test, status });
});

function findStudentByName(db, name) {
  const target = String(name || "").trim().toLowerCase();
  if (!target) return null;
  return db.students.find(s => s.name.toLowerCase() === target)
    || db.students.find(s => s.name.toLowerCase().includes(target));
}

async function aiCommand(req, res) {
  const command = String((req.body || {}).command || "").trim();
  if (!command) return res.status(400).json({ error: "Command is required" });

  const lower = command.toLowerCase();
  const db = await readDb();

  // Add student: English + Roman Urdu patterns
  const add = command.match(
    /add\s+student\s+(.+?)(?:\s+class\s+(6th|7th|8th|9th|10th|11th|12th))?(?:\s+phone\s+([+\d-]{10,15}))?/i
  ) || command.match(
    /(?:student\s+)?(.+?)\s+ko\s+(?:class\s+)?(6th|7th|8th|9th|10th|11th|12th)\s+(?:mein\s+)?add\s+karo(?:\s+phone\s+([+\d-]{10,15}))?/i
  );

  if (add && (lower.includes("add student") || lower.includes("add karo"))) {
    const name = add[1].trim();
    const studentClass = normalizeClass(add[2]);
    const phone = normalizePhone(add[3] || "");
    if (!name || !classes.includes(studentClass)) {
      return res.json({ type: "error", message: "Student name aur 6th-12th class required hai." });
    }

    const student = {
      id: uid("stu"),
      name,
      fatherName: "",
      class: studentClass,
      phone,
      rollNo: "",
      fee: 0,
      feeStatus: "pending",
      attendance: "unmarked",
      createdAt: new Date().toISOString()
    };
    db.students.unshift(student);
    await addActivity(db, "ai", `AI added ${name} to ${studentClass}`);
    await writeDb(db);
    return res.json({ type: "success", action: "student_added", message: `${name} ko ${studentClass} mein add kar diya gaya.`, data: student });
  }

  // Attendance: "Ahmad ko hazir/absent karo"
  const attMatch = command.match(/(.+?)\s+ko\s+(hazir|present|absent|ghair\s*hazir)\s+karo/i);
  if (attMatch) {
    const student = findStudentByName(db, attMatch[1]);
    if (!student) return res.json({ type: "error", message: `${attMatch[1].trim()} naam ka student nahi mila.` });

    const wanted = attMatch[2].toLowerCase();
    const isPresent = wanted === "hazir" || wanted === "present";
    const date = today();
    let record = db.attendance.find(a => a.date === date && a.class === student.class);
    if (!record) {
      record = { id: uid("att"), date, class: student.class, presentIds: [], absentIds: [] };
      db.attendance.push(record);
    }

    record.presentIds = record.presentIds.filter(id => id !== student.id);
    record.absentIds = record.absentIds.filter(id => id !== student.id);

    if (isPresent) {
      record.presentIds.push(student.id);
      student.attendance = "present";
    } else {
      record.absentIds.push(student.id);
      student.attendance = "absent";
    }

    await addActivity(db, "ai", `${student.name} marked ${isPresent ? "present" : "absent"} by AI`);
    await writeDb(db);
    return res.json({ type: "success", action: "attendance", message: `${student.name} ko ${isPresent ? "hazir" : "absent"} mark kar diya gaya.` });
  }

  // Pending fee
  const feeMatch = command.match(/(6th|7th|8th|9th|10th|11th|12th).*pending\s*fee/i)
    || command.match(/(6th|7th|8th|9th|10th|11th|12th)\s+ki\s+pending\s*fee/i);
  if (feeMatch) {
    const studentClass = normalizeClass(feeMatch[1]);
    const students = db.students.filter(s => s.class === studentClass && s.feeStatus !== "paid");
    const total = students.reduce((sum, s) => sum + Number(s.fee || 0), 0);
    return res.json({
      type: "fee_pending",
      message: `${studentClass} mein ${students.length} students ki pending fee Rs. ${total.toLocaleString("en-PK")} hai.`,
      data: { class: studentClass, total, students }
    });
  }

  if (lower.includes("absent") && (lower.includes("whatsapp") || lower.includes("wa.me"))) {
    const date = today();
    const absentIds = new Set(
      db.attendance.filter(a => a.date === date).flatMap(a => a.absentIds || [])
    );
    const students = db.students.filter(s => absentIds.has(s.id) && s.phone);
    const links = students.map(s => ({
      name: s.name,
      url: `https://wa.me/${normalizePhone(s.phone).replace(/^0/, "92")}?text=${encodeURIComponent(`Assalam o Alaikum ${s.name}, aap aaj academy mein absent thay. Barah-e-karam academy se rabta karein.`)}`
    }));
    return res.json({
      type: "whatsapp",
      message: `${links.length} absent students ke WhatsApp links ready hain.`,
      data: { links }
    });
  }

  if (lower.includes("student") && (lower.includes("dikhao") || lower.includes("show") || lower.includes("list"))) {
    const classMatch = lower.match(/(6th|7th|8th|9th|10th|11th|12th)/);
    const studentClass = classMatch ? normalizeClass(classMatch[1]) : "";
    const students = studentClass ? db.students.filter(s => s.class === studentClass) : db.students;
    return res.json({
      type: "students",
      message: `${studentClass || "All"} students: ${students.length}`,
      data: { students }
    });
  }

  if (lower.includes("dashboard")) {
    const pending = db.students.filter(s => s.feeStatus !== "paid")
      .reduce((sum, s) => sum + Number(s.fee || 0), 0);
    return res.json({
      type: "dashboard",
      message: `Dashboard: ${db.students.length} students, Rs. ${pending.toLocaleString("en-PK")} pending fee.`,
      data: { students: db.students.length, pendingFees: pending }
    });
  }

  if (lower.includes("attendance") || lower.includes("hazri")) {
    const records = db.attendance.filter(a => a.date === today());
    const present = new Set(records.flatMap(a => a.presentIds || [])).size;
    const absent = new Set(records.flatMap(a => a.absentIds || [])).size;
    return res.json({
      type: "attendance",
      message: `Aaj ${present} present aur ${absent} absent marked hain.`,
      data: { present, absent }
    });
  }

  if (lower.includes("11am") || lower.includes("11 am") || lower.includes("test")) {
    const test = (db.tests || []).find(t => t.date === today()) || { title: "Daily ETEA Style Test", time: "11:00", status: "scheduled" };
    return res.json({
      type: "test",
      message: `${test.title} ${test.time} par scheduled hai.`,
      data: test
    });
  }

  return res.json({
    type: "help",
    message: "Command samajh nahi aayi. Try: “Ahmad ko hazir karo”, “9th ki pending fee”, “Absent ko WhatsApp bhejo”, ya “Add student Bilal class 10th phone 0345-1234567”."
  });
}

app.post("/api/ai/command", auth, aiCommand);

app.use(express.static(PUBLIC_DIR));

app.get("*", (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, "index.html"));
});

ensureDb().then(() => {
  app.listen(PORT, () => {
    console.log(`Academy Management System running on http://localhost:${PORT}`);
  });
}).catch(err => {
  console.error("Database initialization failed:", err);
  process.exit(1);
});
